<?php 
    session_start();

    $conn = mysqli_connect
    (
    'localhost',
    'root',
    '',
    'usuarios'
    ); 

    if (!$conn) {
        die("Error de conexión: " . mysqli_connect_error());
    }
?>
