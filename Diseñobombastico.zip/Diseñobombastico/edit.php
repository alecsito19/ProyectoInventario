<?php include("db.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.1/dist/morph/bootstrap.min.css">
    <title>Agregar usuarios</title>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-light" data-bs-theme="light">
  <div class="container-fluid">
  <a class="navbar-brand" href="agregar.php">
        <img src="img/04f141e94d06472ce9bc378cc243007dn9OTD7DyWJiDbN8A-0.png" width="70" height="70 " alt="logo">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor03">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="agregar.php">Agregar usuario</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Gestión de inventario</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="usuarios.php">Registro de usuarios</a>
        </li>
      </ul>
    </div>
  </div>
  </ul>
</nav>


<?php

if(isset($_GET['id'])){
    $id= $_GET['id'];
    $query= "SELECT * FROM task WHERE id=$id";
    $result= mysqli_query($conn, $query);

    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $nombres = $row['nombres'];
        $apellidos = $row['apellidos'];
        $usuario = $row['usuario'];
        $contra = $row['contra'];
        $rol = $row['rol'];
    }
}

    if(isset($_POST['update'])){
        $id = $_GET['id'];
        $nombres = $_POST['nombres'];
        $apellidos = $_POST['apellidos'];
        $usuario = $_POST['usuario'];
        $contra = $_POST['contra'];
        $rol = $_POST['rol'];

        $query="UPDATE task set nombres ='$nombres', apellidos = '$apellidos', usuario = '$usuario', contra = '$contra', rol = '$rol' WHERE id = $id";
        mysqli_query($conn, $query);

        $_SESSION['message'] = "Los datos han sido Actualizados";
        $_SESSION['message_type'] = "warning";
        header("Location:usuarios.php");
    }

?>


<div class="container p-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card card-body bg-light">
                <form action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST">
                <div class="form-group">
                          <label for="nombres" class="form-label mt-2">Actualizar nombres</label>
                            <input type="text" name="nombres" id="nombres" class = "form-control bg-secondary" value="<?php echo $nombres ?>" autofocus>
                        </div>

                        <div class="form-group mt-1">
                            <label for="apellidos" class="form-label">Actualizar apellidos</label>
                            <input type="text" name="apellidos" id="apellidos" class = "form-control bg-secondary" value="<?php echo $apellidos ?>" autofocus>
                        </div>
               
                        <div class="form-group mt-1">
                            <label for="usuario" class="form-label">Actualizar usuario</label>
                            <input name="usuario" class = "form-control bg-secondary" value="<?php echo $usuario ?>" autofocus>
                        </div>

                        <div class="form-group mt-1">
                            <label for="contra" class="form-label">Actualizar contraseña</label>
                            <input name="contra" class = "form-control bg-secondary" value="<?php echo $contra ?>" autofocus>
                        </div>

                        <div class="form-group mt-1">
                          <label for="rol" class="form-label">Seleccione el rol del usuario</label>
                          <select name="rol" class="form-select" id="rol">
                            <option><?php echo $rol?></option>
                            <option value="Administrador">Administrador</option>
                            <option value ="Usuario">Usuario</option>
                          </select>
                  </div>
                    <br>
                    <button class="btn btn-success" name="update"> Actualizar </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://kit.fontawesome.com/90ddf4e72e.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>