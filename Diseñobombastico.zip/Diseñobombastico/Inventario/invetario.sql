-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 11-09-2023 a las 07:40:14
-- Versión del servidor: 8.0.31
-- Versión de PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `invetario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `task`
--

DROP TABLE IF EXISTS `task`;
CREATE TABLE IF NOT EXISTS `task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `opciones` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codprod` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `origen` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `donante` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proveedor` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `precio` float(10,2) NOT NULL,
  `factura` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `condicion` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_baja_mostrada` date NOT NULL,
  `observaciones` varchar(65) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_codigo_codprod` (`codigo`,`codprod`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `task`
--

INSERT INTO `task` (`id`, `opciones`, `codigo`, `codprod`, `descripcion`, `modelo`, `fecha`, `origen`, `donante`, `proveedor`, `precio`, `factura`, `condicion`, `fecha_baja_mostrada`, `observaciones`) VALUES
(1, 'Mobiliario', '01', '001', 'saf', 'sfde', '2023-09-16', 'Donado', 'wer', 'N/A', 0.00, 'N/A', 'Buena', '0000-00-00', 'wer'),
(2, 'Mobiliario', '01', '002', 'ewrw', 'wer', '2023-09-08', 'Compra Directa', 'N/A', 'sdfsdf', 3424.00, 'sdfs', 'Buena', '0000-00-00', 'sdf'),
(3, 'Mobiliario', '01', '003', 'saf', 'sadas', '2023-09-06', 'Donado', 'asd', 'N/A', 0.00, 'N/A', 'De baja', '0000-00-00', 'asdasd'),
(4, 'Mobiliario', '01', '004', 'saf', 'sdf', '2023-09-06', 'Compra Directa', 'N/A', 'sdf', 453.00, 'dsf', 'De baja', '2023-09-10', 'sdf'),
(5, 'Mobiliario', '01', '005', 'olaxzdxd', 'sfde', '2023-09-08', 'Donado', 'fg', 'N/A', 0.00, 'N/A', 'De baja', '2023-10-01', 'sdf'),
(6, 'Equipo de Computo', '02', '001', 'olaxzdxd', 'wqe', '2023-09-09', 'Donado', 'wer', 'N/A', 0.00, 'N/A', 'De baja', '0000-00-00', 'qe'),
(7, 'Mobiliario', '01', '006', 'SADA', 'ASDA', '2023-09-09', 'Donado', 'asd', 'N/A', 0.00, 'N/A', 'De baja', '2023-09-23', 'ASDASD'),
(8, 'Mobiliario', '01', '007', 'sad', 'asd', '2023-09-21', 'Donado', 'asd', 'N/A', 0.00, 'N/A', 'Buena', '0000-00-00', 'asd'),
(9, 'Mobiliario', '01', '008', 'ewrwer', 'sdfsdf', '2023-09-15', 'Donado', 'sdf', 'N/A', 0.00, 'N/A', 'De baja', '2023-09-14', 'sdf'),
(10, 'Mobiliario', '01', '009', '', '', '0000-00-00', '', '', '', 0.00, '', '', '0000-00-00', ''),
(11, 'Mobiliario', '01', '010', '', '', '0000-00-00', '', '', '', 0.00, '', '', '0000-00-00', ''),
(12, 'Mobiliario', '01', '011', 'asd', 'asd', '2023-09-09', 'Compra Directa', 'N/A', 'asda', 2311.00, 'asda', 'Regular', '0000-00-00', 'asd'),
(13, 'Mobiliario', '01', '012', 'sad', 'asd', '2023-09-23', 'Compra Directa', 'N/A', 'asd', 342.00, 'sadas', 'Necesita mantenimiento', '0000-00-00', 'asd'),
(14, 'Mobiliario', '01', '013', 'adsd', 'asd', '2023-09-08', 'Donado', 'asdasd', 'N/A', 0.00, 'N/A', 'Regular', '0000-00-00', 'asda'),
(15, 'Mobiliario', '01', '014', 'asd', 'asd', '2023-09-08', 'Donado', 'asd', 'N/A', 0.00, 'N/A', 'Regular', '0000-00-00', 'asd'),
(16, 'Mobiliario', '01', '015', 'wqeqw', 'qwe', '2023-09-13', 'Donado', 'qwe', 'N/A', 0.00, 'N/A', 'Buena', '0000-00-00', 'qwe'),
(17, 'Mobiliario', '01', '016', 'ASDA', 'ASDAS', '2023-09-01', 'Donado', 'AWEASD', 'N/A', 0.00, 'N/A', 'Excelente', '0000-00-00', 'ASD'),
(18, 'Mobiliario', '01', '017', 'sad', 'asd', '2023-09-03', 'Donado', 'asd', 'N/A', 0.00, 'N/A', 'Regular', '0000-00-00', 'asd'),
(19, 'Mobiliario', '01', '018', 'asd', 'asd', '2023-09-09', 'Donado', 'asd', 'N/A', 0.00, 'N/A', 'En mantenimiento', '0000-00-00', 'asdas'),
(20, 'Mobiliario', '01', '019', 'dcgf', 'dfgd', '2023-09-03', 'Donado', 'dfg', 'N/A', 0.00, 'N/A', 'Necesita mantenimiento', '0000-00-00', 'dfg'),
(21, 'Mobiliario', '01', '020', 'dasd', 'asdas', '2023-09-15', 'Donado', 'asdas', 'N/A', 0.00, 'N/A', 'Regular', '0000-00-00', 'asd');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contrasena` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `contrasena`) VALUES
(1, 'user', '1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
