<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.1/dist/morph/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <?php include("db.php")?>

    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>

            <div class="col-md-8 mt-5">
                <div class="card mt-5">
                    <div class="card-body">
                        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
                            <?php 
                                // Verifica si se ha enviado el formulario
                                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                    // Datos de conexión a la base de datos
                                    $servidor = "localhost";
                                    $usuario_db = "root";
                                    $contrasena_db = "";
                                    $nombre_db = "invetario";

                                    // Conectar a la base de datos
                                    $conexion = mysqli_connect($servidor, $usuario_db, $contrasena_db, $nombre_db);

                                    // Verificar la conexión
                                    if (!$conexion) {
                                        die("Error de conexión: " . mysqli_connect_error());
                                    }

                                    // Obtener datos del formulario
                                    $usuario = $_POST["usuario"];
                                    $contrasena = $_POST["contrasena"];

                                    // Consulta SQL para verificar las credenciales del usuario
                                    $consulta = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND contrasena = '$contrasena'";
                                    $resultado = mysqli_query($conexion, $consulta);

                                    // Verificar si se encontró un usuario con las credenciales proporcionadas
                                    if (mysqli_num_rows($resultado) == 1) {
                                        echo "Inicio de sesión exitoso. Bienvenido, " . $usuario;
                                        header("Location: inventario.php");
                                    } else {
                                        echo '<div class="alert alert-danger"> Credencials incorrectas, intentalo de nuevo </div>';
                                    }

                                    // Cerrar la conexión a la base de datos
                                    mysqli_close($conexion);
                                }
                            ?>

                            <div class="mb-3 mt-2">
                                <label class="form-label">Usuario: </label>
                                <input type="text" class="form-control" id="usuario" name="usuario" aria-describedby="emailHelp">
                            </div>

                            <div class="mb-3 mt-2">
                                <label class="form-label">Contraseña</label>
                                <input type="password" class="form-control" id="contrasena" name="contrasena">
                            </div>
                            
                            <button type="submit" name="btningresar" value="Iniciar Sesión" class="btn btn-primary"> Iniciar Sesión</button>
                        </form>
                    </div>
                </div>
            </div>    

            <div class="col-md-2"></div>
        </div>
    </div>
</body>
</html>