<?php
require 'PhpSpreadsheet/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['formSubmitted'])) {
    // Conecta a tu base de datos (reemplaza con tus propios datos de conexión)
    $dbHost = 'localhost';
    $dbName = 'invetario'; // Nombre de tu base de datos
    $dbUser = 'root';
    $dbPass = '';

    $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Consulta SQL para seleccionar todos los campos de la tabla "task"
    $query = "SELECT * FROM task"; // Ajusta la tabla según tu esquema de base de datos
    $result = $conn->query($query);

    // Crear una nueva hoja de cálculo
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Encabezado
    $header = array(
        'ID',
        'Categoría',
        'Código de Categoría',
        'Código de Producto',
        'Modelo del producto',
        'Descripción',
        'Fecha',
        'Origen',
        'Donante',
        'Proveedor',
        'Precio',
        'Factura',
        'Condición',
        'Fecha Baja Mostrada',
        'Observaciones'
    );

    $sheet->fromArray([$header], null, 'B3');

    // Datos
    $row = 4; // Comenzar en la fila 4
    while ($data = $result->fetch_assoc()) {
        $sheet->fromArray(array_values($data), null, 'B' . $row);
        $row++;
    }

    // Crear un objeto de escritura para Excel
    $writer = new Xlsx($spreadsheet);

    // Nombre del archivo
    $filename = 'informe.xlsx';

    // Configurar encabezados HTTP para descarga de archivo
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    // Enviar el archivo al navegador
    $writer->save('php://output');

    // Cierra la conexión a la base de datos
    $conn->close();
}
?>
