<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.1/dist/morph/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <title>Inventario</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="inventario.php">Inventario general</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Features</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pricing</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</body>
</html>

<?php

include("db.php");

if(isset($_GET['id'])){
    $id= $_GET['id'];
    $query= "SELECT * FROM task WHERE id=$id";
    $result= mysqli_query($conn, $query);

    if(mysqli_num_rows($result)==1){
        $row = mysqli_fetch_array($result);
        $codigo = $row['codigo'];
        $fecha = $row['fecha'];
        $descripcion = $row['descripcion'];
        $modelo = $row['modelo'];
        $tipo = $row['tipo'];
        $origen = $row['origen'];
        $donante = $row['donante'];
        $proveedor = $row['proveedor'];
        $factura = $row['factura'];
        $condicion = $row['condicion'];
        $observaciones = $row['observaciones'];
        $precio = $row['precio'];
    }
}

    if(isset($_POST['update'])){
        $id = $_GET['id'];
        $codigo = $row['codigo'];
        $fecha = $_POST['fecha'];
        $descripcion = $_POST['descripcion'];
        $modelo = $_POST['modelo'];
        $tipo = $_POST['tipo'];
        $origen = $_POST['origen'];
        $donante = $_POST['donante'];
        $proveedor = $_POST['proveedor'];
        $factura = $_POST['factura'];
        $condicion = $_POST['condicion'];
        $observaciones = $_POST['observaciones'];
        $precio = $_POST['precio'];


        $query="UPDATE task set fecha='$fecha', descripcion='$descripcion', modelo='$modelo', tipo='$tipo', origen='$origen', donante='$donante', proveedor='$proveedor', factura='$factura', condicion='$condicion', observaciones='$observaciones', precio='$precio' WHERE id = $id";
        mysqli_query($conn, $query);


        $_SESSION['message'] = "Los datos han sido Actualizados";
        $_SESSION['message_type'] = "warning";
        header("Location:inventario.php");
    }

?>


<div class="container p-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card card-body">
                <form action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST">

                <div class="from-group">
                    <div>
                       <input type="text" name="codigo" value="<?php echo $codigo ?>" class="form-control mt-3" placeholder="Actualizar código">
                    </div>

                    <div>
                       <input type="date" name="fecha" value="<?php echo $fecha ?>" class="form-control mt-3" placeholder="Actualizar fecha">
                    </div>

                    <div>
                        <textarea name="descripcion"  class="form-control mt-2" placeholder="Actualizar descripcion"><?php echo $descripcion; ?></textarea>
                    </div>

                    <div>
                        <textarea name="modelo"  class="form-control mt-2" placeholder="Actualizar modelo"><?php echo $modelo; ?></textarea>
                    </div>

                    <div>
                        <label for="disabledSelect" class="form-label mt-2">Tipo</label>
                        <select id="tipo" class="form-select">
                            <option value=""> -- </option>
                            <option value="Mobilario"> Mobilario </option>
                            <option value="Equipo de computo"> Equipo de computo</option>
                            <option value="Equipo de oficina">Equipo de oficina</option>
                            <option value="Mobiliario de oficina">Mobiliario de oficina</option>
                            <option value="Mobiliario">Mobiliario</option>
                </div>


                    <div>
                        <textarea name="origen"  class="form-control mt-2" placeholder="Actualizar origen"><?php echo $origen; ?></textarea>
                    </div>

                    <div>
                        <textarea name="donante"  class="form-control mt-2" placeholder="Actualizar origen"><?php echo $donante; ?></textarea>
                    </div>

                    <div>
                        <textarea name="proveedor"  class="form-control mt-2" placeholder="Actualizar proveedor"><?php echo $proveedor; ?></textarea>
                    </div>

                        <input type="number" name="factura" value="<?php echo $factura ?>" class="form-control mt-2" placeholder="Actualizar factura">
                    </div>

                    <div>
                        <textarea name="condicion"  class="form-control mt-2" placeholder="Actualizar condicion"><?php echo $condicion; ?></textarea>
                    </div>

                    <div>
                        <textarea name="observaciones"  class="form-control mt-2" placeholder="Actualizar observaciones"><?php echo $observaciones; ?></textarea>
                    </div>

                    <div>
                        <input type="number" name="precio" value="<?php echo $precio ?>" class="form-control mt-2" placeholder="Actualizar precio">
                    </div>

                    <br>
                    <button class="btn btn-success" name="update"> Actualizar </button>

                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://kit.fontawesome.com/90ddf4e72e.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>

 


