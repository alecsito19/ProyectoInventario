<?php
    if (file_exists('informe.xlsx')) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="informe.xlsx"');
    readfile('informe.xlsx');
    } else {
    echo 'El informe no está disponible para descargar.';
    }
?>
