<?php include("db.php")?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.1/dist/morph/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>    <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>    <link rel="stylesheet" href="css/style.css">
    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
    <!-- DATATABLES -->
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <!-- BOOTSTRAP -->
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

    <style>
        /* Estilos personalizados para el menú de selección de longitud */
        .dataTables_length {
            white-space: nowrap; /* Evita el salto de línea */
        }
    </style>
    <title>Inventario</title>
</head>
<body> 
    <div class="container">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container">
        <a class="navbar-brand" href="inventario.php"><img src="issets/logo/logoisdm.png" class="img-logo"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
            <li class="nav-item">
            <a class="nav-link fs-2" href="">Inventario de Mobiliario y Equipo</a>
            </li>
        </ul>
        <button type="button" class="btn btn-danger"><a href="logout.php" class="text-decoration-none text-white">Cerrar Sesión</a></button>
        </div>
    </div>
    </nav> 

    <div class="table-container text-center">
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-9">
                        <p class="fs-2"> Buscar productos </p>
                    </div>

                    <div class="col-md-3">

                        
                    </div>
                </div>

            <div class="row">
                <div class="col-md-9">
                    <div col-md-4>
                        <input id="myInput" type="text" placeholder="Buscar" class="form-control mt-2">
                    </div>
                </div>

                <div class="col-md-3 mt-2">
                    <form action="generar_informe.php" method="post">
                        <!-- Botón para generar el informe -->
                        <button type="submit" class="btn btn-success btn-black" name="generateReport">Generar Informe</button>
                        <!-- Campo oculto para indicar que se envió el formulario por medio del botón -->
                        <input type="hidden" name="formSubmitted" value="true">
                    </form>
                </div>
            </div>
                
        
            <div class="col-md-12 mt-4">
                <table name="tablax" id="tablax" class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th class="col-1">Código</th>
                            <th class="col-1">Categoría</th>
                            <th class="col-2">Fecha</th>
                            <th class="col-3">Descripción</th>
                            <th class="col-1">Origen de adquisición</th>
                            <th class="col-2">Precio</th>
                            <th class="col-2">Condición</th>    
                            <th class="">Más Información</th>  
                        </tr>
                    </thead>

                    <tbody id="myTable">
                        <?php
                        $query = "SELECT * FROM task";
                        $result_task=mysqli_query($conn, $query);

                        while ($row = mysqli_fetch_array($result_task)){?>
                        <tr>
                            <td><?php echo $row['codigo'] . $row['codprod']?></td>
                            <td><?php echo $row['opciones']?></td>
                            <td><?php echo $row['fecha']?></td>
                            <td><?php echo $row['descripcion']?></td>
                            <td><?php echo $row['origen']?></td>
                            <td> Q <?php echo $row['precio']?></td>
                            <td><?php echo $row['condicion']?></td>            
                            <td>
                                
                        <!-- Button trigger modal -->
                        <a type="button" class="ml-3" data-bs-toggle="modal" data-bs-target="#exampleModal"
                                data-codigo="<?php echo $row['codigo'] . $row['codprod'] ?>"
                                data-modelo="<?php echo $row['modelo'] ?>"
                                data-donante="<?php echo $row['donante'] ?>"
                                data-proveedor="<?php echo $row['proveedor'] ?>"
                                data-factura="<?php echo $row['factura'] ?>"
                                data-condicion="<?php echo $row['condicion'] ?>"
                                data-fecha_baja_mostrada="<?php echo $row['fecha_baja_mostrada'] ?>"
                                data-observaciones="<?php echo $row['observaciones'] ?>">
                                
                                <i class="fa-solid fa-plus"></i>
                        </a>

                                            
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content modal-xl">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Información adicional</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body ">
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th>codigo</th>
                                                <th>Modelo</th>
                                                <th>Nombre de donante</th>
                                                <th>Proveedor</th>
                                                <th>No. factura</th>
                                                <th>Condición</th>
                                                <th>Fecha de Baja</th>
                                                <th>Observaciones</th>
                                            </tr>
                                            </thead>

                                            <tbody id="modalContent">
                                                <!-- Aquí se cargará la información del registro -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

    <script>
        const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
        const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))
    </script>

    <script> 
        const myModal = document.getElementById('myModal')
        const myInput = document.getElementById('myInput')

        myModal.addEventListener('shown.bs.modal', () => {
        myInput.focus()
        })
    </script>


    <script>
        // Obtener referencias a los elementos del DOM
        const origenSelect = document.getElementById("origen");
        const donanteInput = document.getElementById("donante");
        const proveedorInput = document.getElementById("proveedor");
        const precioInput = document.getElementById("precio");
        const facturaInput = document.getElementById("factura");

        // Agregar un evento de cambio al select
        origenSelect.addEventListener("change", function() {
            // Verificar si la opción seleccionada es "Donado"
            if (origenSelect.value === "Donado") {
                // Si es "Donado", establecer los campos en "N/A"
                proveedorInput.value = "N/A";
                precioInput.value = "0.00";
                facturaInput.value = "N/A";
            } else {
                // Si no es "Donado", borrar los valores de los campos
                proveedorInput.value = "";
                precioInput.value = "";
                facturaInput.value = "";
            }

            if (origenSelect.value === "Compra Directa") {
                // Si es "Donado", establecer los campos en "N/A"
                donanteInput.value = "N/A";
            } else {
                // Si no es "Donado", borrar los valores de los campos
                donanteInput.value = "";

            }
        });
    </script>

    <script>
        $(document).ready(function(){
            $('[data-toggle="popover"]').popover({
                html: true  // Permite el uso de HTML en el contenido del popover
            });
        });
    </script>

    
    <script>
        // Al abrir el modal, cargar la información del registro correspondiente
        $('#exampleModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Botón que activó el modal
            var modal = $(this);
            modal.find('.modal-title').text('Información adicional - ' + button.data('codigo')); // Cambiar el título del modal

            // Construir el contenido del modal con los datos del botón
            var modalContent = '<tr>' +
                '<td>' + button.data('codigo') + '</td>' +
                '<td>' + button.data('modelo') + '</td>' +
                '<td>' + button.data('donante') + '</td>' +
                '<td>' + button.data('proveedor') + '</td>' +
                '<td>' + button.data('factura') + '</td>' +
                '<td>' + button.data('condicion') + '</td>' +
                '<td>' + button.data('fecha_baja_mostrada') + '</td>' +
                '<td>' + button.data('observaciones') + '</td>' +
                '</tr>';

            // Colocar la información en el modal
            $('#modalContent').html(modalContent);
        });
    </script>

    <script>
        function validateForm() {
            var opciones = document.getElementById("opciones").value;
            var codigo = document.getElementById("codigo").value;
            var codprod = document.getElementById("codprod").value;
            var descripcion = document.getElementsByName("descripcion")[0].value;
            var modelo = document.getElementsByName("modelo")[0].value;
            var fecha = document.getElementsByName("fecha")[0].value;
            var origen = document.getElementById("origen").value;
            var donante = document.getElementsByName("donante")[0].value;
            var proveedor = document.getElementsByName("proveedor")[0].value;
            var precio = document.getElementsByName("precio")[0].value;
            var factura = document.getElementsByName("factura")[0].value;
            var condicion = document.getElementsByName("condicion")[0].value;
            var observaciones = document.getElementsByName("observaciones")[0].value;
            const alertMessage = document.getElementById('alertMessage'); // Obtener la alerta

            if (
                opciones === "" ||
                codigo === "" ||
                codprod === "" ||
                descripcion === "" ||
                modelo === "" ||
                fecha === "" ||
                origen === "" ||
                donante === "" || // Hacer este campo obligatorio incluso si es "Donado"
                proveedor === "" || // Hacer este campo obligatorio incluso si es "Compra Directa"
                precio === "" ||
                factura === "" ||
                condicion === "" ||
                observaciones === ""
            ) {
                // Mostrar la alerta de Bootstrap
                document.getElementById("alertMessage").style.display = "block";
                return false;
            }
                
            // Verificar si la condición es "De baja" y validar la fecha
            if (condicion === "De baja" && fecha === "") {
                // Mostrar mensaje de error para seleccionar una fecha
                document.getElementById("fechaError").style.display = "block";
                return false;
            }



            // Función para habilitar o deshabilitar la validación de fecha y mostrar alertas
            function toggleFechaValidation() {
                if (condicionSelect.value === 'De baja') {
                    fechaBajaModal.show();
                    fechaBajaInput.required = true;
                    alertMessage.style.display = 'none'; // Ocultar la alerta si es visible
                } else {
                    fechaBajaModal.hide();
                    fechaBajaInput.required = false;
                    fechaBajaInput.value = ""; // Borra el valor si no es necesario
                    fechaBajaMostradaInput.value = ""; // Borra el valor mostrado
                    alertMessage.style.display = 'block'; // Mostrar la alerta si no se selecciona fecha
                }
            }

            return true;
        }

        // Función para ocultar el mensaje de error de fecha cuando cambia la condición
        function hideFechaError() {
            document.getElementById("fechaError").style.display = "none";
        }

        // Agregar un evento de cambio al campo de condición
        document.getElementsByName("condicion")[0].addEventListener("change", hideFechaError);
    </script>



    <script>
        function seleccionarCodigo() {
            var opciones = document.getElementById("opciones");
            var codigo = document.getElementById("codigo");
            var codprod = document.getElementById("codprod");

            // Obtén el valor seleccionado en el campo de categoría
            var categoriaSeleccionada = opciones.value;

            // Muestra el valor de la categoría tanto en el campo "categoría" como en el campo "código"
            codigo.value = categoriaSeleccionada;

            // Aquí puedes asignar automáticamente un código en función de la opción seleccionada
            switch (categoriaSeleccionada) {
                case "":
                    codigo.value = "Elegir una categoría";
                    codprod.value = ""; // Limpia el valor de "codprod" cuando no se selecciona una categoría
                    break;
                case "Mobiliario":
                    // Consulta para obtener el número máximo actual para "Mobiliario"
                    <?php
                    $query = "SELECT MAX(codprod) AS max_codprod FROM task WHERE opciones = 'Mobiliario'";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($result);

                    // Obtén el máximo actual o establece 0 si no hay registros
                    $maxCodprod = ($row['max_codprod'] != null) ? intval($row['max_codprod']) : 0;

                    // Incrementa el valor para el siguiente registro y asegúrate de que no supere 999
                    $maxCodprod = ($maxCodprod >= 999) ? 1 : $maxCodprod + 1;

                    // Formatea el valor como "001", "002", etc.
                    $nextCodprod = sprintf("%03d", $maxCodprod);
                    ?>

                    codigo.value = "01";
                    // Asigna el valor al campo "codprod"
                    codprod.value = "<?php echo $nextCodprod; ?>";
                    break;
                case "Equipo de Computo":
                    // Consulta para obtener el número máximo actual para "Equipo de Computo"
                    <?php
                    $query = "SELECT MAX(codprod) AS max_codprod FROM task WHERE opciones = 'Equipo de Computo'";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($result);

                    // Obtén el máximo actual o establece 0 si no hay registros
                    $maxCodprod = ($row['max_codprod'] != null) ? intval($row['max_codprod']) : 0;

                    // Incrementa el valor para el siguiente registro y asegúrate de que no supere 999
                    $maxCodprod = ($maxCodprod >= 999) ? 1 : $maxCodprod + 1;

                    // Formatea el valor como "001", "002", etc.
                    $nextCodprod = sprintf("%03d", $maxCodprod);
                    ?>

                    codigo.value = "02";
                    // Asigna el valor al campo "codprod"
                    codprod.value = "<?php echo $nextCodprod; ?>";
                    break;
                case "Equipo de Oficina":
                    // Consulta para obtener el número máximo actual para "Equipo de Oficina"
                    <?php
                    $query = "SELECT MAX(codprod) AS max_codprod FROM task WHERE opciones = 'Equipo de Oficina'";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($result);

                    // Obtén el máximo actual o establece 0 si no hay registros
                    $maxCodprod = ($row['max_codprod'] != null) ? intval($row['max_codprod']) : 0;

                    // Incrementa el valor para el siguiente registro y asegúrate de que no supere 999
                    $maxCodprod = ($maxCodprod >= 999) ? 1 : $maxCodprod + 1;

                    // Formatea el valor como "001", "002", etc.
                    $nextCodprod = sprintf("%03d", $maxCodprod);
                    ?>

                    codigo.value = "03";
                    // Asigna el valor al campo "codprod"
                    codprod.value = "<?php echo $nextCodprod; ?>";
                    break;
                case "Electrónicos":
                    // Consulta para obtener el número máximo actual para "Electrónicos"
                    <?php
                    $query = "SELECT MAX(codprod) AS max_codprod FROM task WHERE opciones = 'Electrónicos'";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($result);

                    // Obtén el máximo actual o establece 0 si no hay registros
                    $maxCodprod = ($row['max_codprod'] != null) ? intval($row['max_codprod']) : 0;

                    // Incrementa el valor para el siguiente registro y asegúrate de que no supere 999
                    $maxCodprod = ($maxCodprod >= 999) ? 1 : $maxCodprod + 1;

                    // Formatea el valor como "001", "002", etc.
                    $nextCodprod = sprintf("%03d", $maxCodprod);
                    ?>

                    codigo.value = "04";
                    // Asigna el valor al campo "codprod"
                    codprod.value = "<?php echo $nextCodprod; ?>";
                    break;
                case "Otros":
                    // Consulta para obtener el número máximo actual para "Otros"
                    <?php
                    $query = "SELECT MAX(codprod) AS max_codprod FROM task WHERE opciones = 'Otros'";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_fetch_assoc($result);

                    // Obtén el máximo actual o establece 0 si no hay registros
                    $maxCodprod = ($row['max_codprod'] != null) ? intval($row['max_codprod']) : 0;

                    // Incrementa el valor para el siguiente registro y asegúrate de que no supere 999
                    $maxCodprod = ($maxCodprod >= 999) ? 1 : $maxCodprod + 1;

                    // Formatea el valor como "001", "002", etc.
                    $nextCodprod = sprintf("%03d", $maxCodprod);
                    ?>

                    codigo.value = "05";
                    // Asigna el valor al campo "codprod"
                    codprod.value = "<?php echo $nextCodprod; ?>";
                    break;
            }
        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const condicionSelect = document.getElementsByName("condicion")[0];
            const fechaBajaModal = new bootstrap.Modal(document.getElementById('fechaBajaModal'));

            condicionSelect.addEventListener('change', function () {
                if (condicionSelect.value === 'De baja') {
                    fechaBajaModal.show();
                } else {
                    fechaBajaModal.hide();
                }
            });

            // Manejar la confirmación de la fecha de baja
            const confirmarFechaBajaButton = document.getElementById('confirmarFechaBaja');
            const fechaBajaInput = document.getElementById('fecha_baja');

            confirmarFechaBajaButton.addEventListener('click', function () {
                // Copiar la fecha seleccionada al campo "fecha_baja" en el formulario principal
                document.getElementsByName('fecha_baja')[0].value = fechaBajaInput.value;
                fechaBajaModal.hide();
            });

            $('#fechaBajaModal').modal({
                show: false // Esto evita que el modal se abra automáticamente al cargar la página
            });

            $('#tuBoton').on('click', function() {
                $('#fechaBajaModal').modal('show');
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
        const condicionSelect = document.getElementsByName("condicion")[0];
        const fechaBajaModal = new bootstrap.Modal(document.getElementById('fechaBajaModal'));
        const editarFechaBajaBtn = document.getElementById('editarFechaBaja');
        const fechaBajaInput = document.getElementById('fecha_baja');
        const fechaBajaMostradaInput = document.getElementById('fecha_baja_mostrada');

        // Función para habilitar o deshabilitar la validación de fecha
        function toggleFechaValidation() {
            if (condicionSelect.value === 'De baja') {
                fechaBajaModal.show();
                fechaBajaInput.required = true;
            } else {
                fechaBajaModal.hide();
                fechaBajaInput.required = false;
                fechaBajaInput.value = ""; // Borra el valor si no es necesario
                fechaBajaMostradaInput.value = ""; // Borra el valor mostrado
            }
        }

        // Evento para abrir el modal de fecha de baja al hacer clic en "Editar Fecha"
        editarFechaBajaBtn.addEventListener('click', function () {
            toggleFechaValidation();
            fechaBajaModal.show();
        });

        // Evento para actualizar el campo de fecha de baja en modo solo lectura
        fechaBajaInput.addEventListener('change', function () {
            fechaBajaMostradaInput.value = fechaBajaInput.value;
        });

        // Agregar un evento de cambio al campo de condición
        condicionSelect.addEventListener('change', toggleFechaValidation);

        // Llamar a la función para establecer el estado inicial
        toggleFechaValidation();
    });

    </script>

    <script>
        // Función para manejar el cambio en el campo de condición
        function handleCondicionChange() {
            var condicionSelect = document.getElementsByName("condicion")[0];
            var fechaBajaInput = document.getElementsByName("fecha_baja_mostrada")[0];

            if (condicionSelect.value === "De baja") {
                // Habilitar el campo de fecha de baja
                fechaBajaInput.removeAttribute("disabled");
            } else {
                // Deshabilitar el campo de fecha de baja y borrar su valor
                fechaBajaInput.setAttribute("disabled", "disabled");
                fechaBajaInput.value = "";
            }
        }

        // Agregar un evento de cambio al campo de condición
        document.getElementsByName("condicion")[0].addEventListener("change", handleCondicionChange);

        // Llamar a la función para establecer el estado inicial
        handleCondicionChange();

        // Evento para abrir el modal de fecha de baja al hacer clic en "Editar Fecha"
        editarFechaBajaBtn.addEventListener('click', function () {
                    fechaBajaModal.show();
                });

                // Evento para actualizar el campo de fecha de baja en modo solo lectura
                fechaBajaInput.addEventListener('change', function () {
                    fechaBajaMostradaInput.value = fechaBajaInput.value;
                });


    </script>

    <script>
        // Agregar un manejador de eventos al botón "Confirmar Fecha"
        $('#confirmarFechaBaja').on('click', function() {
            // Aquí puedes realizar las acciones que desees cuando se confirma la fecha
            // Por ejemplo, puedes obtener el valor de la fecha seleccionada
            var fechaSeleccionada = $('#fecha_baja').val();
            
            // Por ejemplo, aquí mostraremos la fecha seleccionada en la consola.
            console.log('Fecha seleccionada: ' + fechaSeleccionada);
            
            // Cierra el modal
            $('#fechaBajaModal').modal('hide');
        });
    </script>

    <script>
        // Obtén una referencia a los botones y al elemento de destino
        const save_task = document.getElementById('save_task');
        const btnEliminar = document.getElementById('btnEliminar');
        const btnEditar = document.getElementById('btnEditar');
        const elementoDestino = document.getElementById('elementoDestino');

        // Agregar un manejador de eventos al botón Agregar
        save_task.addEventListener('click', function() {
            // Realiza la acción de agregar aquí

            // Desplázate al elemento de destino después de la acción
            elementoDestino.scrollIntoView({ behavior: 'smooth' });
        });

        // Agregar un manejador de eventos al botón Eliminar
        btnEliminar.addEventListener('click', function() {
            // Realiza la acción de eliminar aquí

            // Desplázate al elemento de destino después de la acción
            elementoDestino.scrollIntoView({ behavior: 'smooth' });
        });

        // Agregar un manejador de eventos al botón Editar
        btnEditar.addEventListener('click', function() {
            // Realiza la acción de editar aquí

            // Desplázate al elemento de destino después de la acción
            elementoDestino.scrollIntoView({ behavior: 'smooth' });
        });
    </script>

    <script>
        $(document).ready(function () {
            $('#tablax').DataTable({
                searching: false,
                lengthMenu: [20],
                lengthChange: false, // Deshabilita la opción de cambiar la longitud de la página
                language: {
                    processing: "Tratamiento en curso...",
                    
                    search: "Buscar&nbsp;:",
                    info: "Mostrando del item _START_ al _END_ de un total de _TOTAL_ items",
                    infoEmpty: "No existen datos.",
                    infoFiltered: "(filtrado de _MAX_ elementos en total)",
                    infoPostFix: "",
                    loadingRecords: "Cargando...",
                    zeroRecords: "No se encontraron datos con tu búsqueda",
                    emptyTable: "No hay datos disponibles en la tabla.",
                    paginate: {
                        first: "Primero",
                        previous: "Anterior",
                        next: "Siguiente",
                        last: "Último"
                    },
                    aria: {
                        sortAscending: ": active para ordenar la columna en orden ascendente",
                        sortDescending: ": active para ordenar la columna en orden descendente"
                    }
                },
                scrollY: 400
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#generarInforme').click(function() {
                // Campos predefinidos que deseas seleccionar
                var camposSeleccionados = [
                    "id",
                    "opciones",
                    "codigo",
                    "codprod",
                    "descripcion",
                    "fecha",
                    "origen",
                    "donante",
                    "proveedor",
                    "precio",
                    "factura",
                    "condicion",
                    "fecha_baja_mostrada",
                    "observaciones"
                ];

                // Genera la solicitud del informe con campos predefinidos
                $.ajax({
                    url: 'generar_informe.php', // Ruta al archivo que generará el informe
                    method: 'POST',
                    data: { campos: camposSeleccionados },
                    success: function(response) {
                        // Redirige a la página de descarga del informe
                        window.location.href = 'descargar_informe.php';
                    },
                    error: function() {
                        alert('Error al generar el informe.');
                    }
                });
            });
        });
    </script>

<script src="https://kit.fontawesome.com/90ddf4e72e.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>
