$(document).ready(function () {
  $("#myInput").on("keyup", function () {
      var value = $(this).val().toLowerCase();
      $("#myTable tr").filter(function () {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
  });
});

const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));

const myModal = document.getElementById('myModal');
const myInput = document.getElementById('myInput');

myModal.addEventListener('shown.bs.modal', () => {
  myInput.focus();
});

const origenSelect = document.getElementById("origen");
const donanteInput = document.getElementById("donante");
const proveedorInput = document.getElementById("proveedor");
const precioInput = document.getElementById("precio");
const facturaInput = document.getElementById("factura");

origenSelect.addEventListener("change", function () {
  if (origenSelect.value === "Donado") {
      proveedorInput.value = "N/A";
      precioInput.value = "0.00";
      facturaInput.value = "N/A";
  } else {
      proveedorInput.value = "";
      precioInput.value = "";
      facturaInput.value = "";
  }

  if (origenSelect.value === "Compra Directa") {
      donanteInput.value = "N/A";
  } else {
      donanteInput.value = "";
  }
});

$(document).ready(function () {
  $('[data-toggle="popover"]').popover({
      html: true
  });
});

$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget);
  var modal = $(this);
  modal.find('.modal-title').text('Información adicional - ' + button.data('codigo'));

  var modalContent = '<tr>' +
      '<td>' + button.data('codigo') + '</td>' +
      '<td>' + button.data('modelo') + '</td>' +
      '<td>' + button.data('donante') + '</td>' +
      '<td>' + button.data('proveedor') + '</td>' +
      '<td>' + button.data('factura') + '</td>' +
      '<td>' + button.data('condicion') + '</td>' +
      '<td>' + button.data('fecha_baja_mostrada') + '</td>' +
      '<td>' + button.data('observaciones') + '</td>' +
      '</tr>';

  $('#modalContent').html(modalContent);
});

function validateForm() {
  var opciones = document.getElementById("opciones").value;
  var codigo = document.getElementById("codigo").value;
  var codprod = document.getElementById("codprod").value;
  var descripcion = document.getElementsByName("descripcion")[0].value;
  var modelo = document.getElementsByName("modelo")[0].value;
  var fecha = document.getElementsByName("fecha")[0].value;
  var origen = document.getElementById("origen").value;
  var donante = document.getElementsByName("donante")[0].value;
  var proveedor = document.getElementsByName("proveedor")[0].value;
  var precio = document.getElementsByName("precio")[0].value;
  var factura = document.getElementsByName("factura")[0].value;
  var condicion = document.getElementsByName("condicion")[0].value;
  var observaciones = document.getElementsByName("observaciones")[0].value;

  if (
      opciones === "" ||
      codigo === "" ||
      codprod === "" ||
      descripcion === "" ||
      modelo === "" ||
      fecha === "" ||
      origen === "" ||
      donante === "" ||
      proveedor === "" ||
      precio === "" ||
      factura === "" ||
      condicion === "" ||
      observaciones === ""
  ) {
      document.getElementById("alertMessage").style.display = "block";
      return false;
  }

  if (condicion === "De baja" && fecha === "") {
      document.getElementById("fechaError").style.display = "block";
      return false;
  }

  return true;
}

function hideFechaError() {
  document.getElementById("fechaError").style.display = "none";
}

document.getElementsByName("condicion")[0].addEventListener("change", hideFechaError);

document.addEventListener('DOMContentLoaded', function () {
  const condicionSelect = document.getElementsByName("condicion")[0];
  const fechaBajaModal = new bootstrap.Modal(document.getElementById('fechaBajaModal'));

  condicionSelect.addEventListener('change', function () {
      if (condicionSelect.value === 'De baja') {
          fechaBajaModal.show();
      } else {
          fechaBajaModal.hide();
      }
  });

  const confirmarFechaBajaButton = document.getElementById('confirmarFechaBaja');
  const fechaBajaInput = document.getElementById('fecha_baja');

  confirmarFechaBajaButton.addEventListener('click', function () {
      document.getElementsByName('fecha_baja')[0].value = fechaBajaInput.value;
      fechaBajaModal.hide();
  });

  $('#fechaBajaModal').modal({
      show: false
  });

  $('#tuBoton').on('click', function () {
      $('#fechaBajaModal').modal('show');
  });
});

document.addEventListener('DOMContentLoaded', function () {
  const condicionSelect = document.getElementsByName("condicion")[0];
  const fechaBajaModal = new bootstrap.Modal(document.getElementById('fechaBajaModal'));
  const editarFechaBajaBtn = document.getElementById('editarFechaBaja');
  const fechaBajaInput = document.getElementById('fecha_baja');
  const fechaBajaMostradaInput = document.getElementById('fecha_baja_mostrada');

  editarFechaBajaBtn.addEventListener('click', function () {
      fechaBajaModal.show();
  });

  fechaBajaInput.addEventListener('change', function () {
      fechaBajaMostradaInput.value = fechaBajaInput.value;
  });
});

$('#confirmarFechaBaja').on('click', function () {
  var fechaSeleccionada = $('#fecha_baja').val();
  console.log('Fecha seleccionada: ' + fechaSeleccionada);
  $('#fechaBajaModal').modal('hide');
});
