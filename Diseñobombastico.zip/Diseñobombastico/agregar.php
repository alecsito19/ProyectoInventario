<?php include("db.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.1/dist/morph/bootstrap.min.css">
    <title>Agregar usuarios</title>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-light" data-bs-theme="light">
  <div class="container-fluid">
  <a class="navbar-brand" href="index.php">
        <img src="img/04f141e94d06472ce9bc378cc243007dn9OTD7DyWJiDbN8A-0.png" width="70" height="70 " alt="logo">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor03">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="agregar.php">Agregar usuario</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="inventario.php">Gestión de inventario</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="usuarios.php">Registro de usuarios</a>
        </li>
      </ul>
    </div>
  </div>
  </ul>
</nav>


<?php  if(isset($_SESSION['message'])) { ?>
    <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
    <?= $_SESSION['message'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php session_unset(); } ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card bg-light mt-4">                
                <div class="card-header"> 
                    <h4>Agregar un usuario</h4>
                </div>
                <div class="card-body">
                    <form action="save.php" method="POST">
                        <div class="form-group">
                          <label for="nombres" class="form-label mt-2">Ingrese los nombres</label>
                            <input type="text" name="nombres" id="nombres" class = "form-control bg-secondary" placeholder= "Nombres" autofocus>
                        </div>

                        <div class="form-group mt-1">
                            <label for="apellidos" class="form-label">Ingrese los apellidos</label>
                            <input type="text" name="apellidos" id="apellidos" class = "form-control bg-secondary" placeholder="Apellidos" autofocus>
                        </div>
               
                        <div class="form-group mt-1">
                            <label for="usuario" class="form-label">Asigne un usuario</label>
                            <input name="usuario" class = "form-control bg-secondary" placeholder="Usuario" autofocus>
                        </div>

                        <div class="form-group mt-1">
                            <label for="contra" class="form-label">Asigne una contraseña</label>
                            <input name="contra" class = "form-control bg-secondary" placeholder="Contraseña" autofocus>
                        </div>

                        <div class="form-group mt-1">
                          <label for="rol" class="form-label">Seleccione el rol del usuario</label>
                          <select name="rol" class="form-select" id="rol">
                            <option>---</option>
                            <option value="Administrador">Administrador</option>
                            <option value ="Usuario">Usuario</option>
                          </select>
                        </div>
<br>
                        <input type="submit"
                            class="btn btn-outline-info" name="save_task" value="Guardar usuario">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://kit.fontawesome.com/90ddf4e72e.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>