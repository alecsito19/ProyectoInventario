<?php
session_start();
if ($_SESSION['loggedin']) {
    $userRole = $_SESSION['userRole'];

    if ($userRole === 'admin') {
        // Mostrar elementos específicos para administradores
        header('Location: indexadmin.php');
    } elseif ($userRole === 'user') {
        // Mostrar elementos específicos para usuarios normales
        header('Location: inventario/inventario_usuario.php');
    }
} else {
    // El usuario no está autenticado, redirigir a la página de inicio de sesión
    header('Location: index.html');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Panel de control</title>
    <!-- Agregar enlaces a los archivos CSS de Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title">Panel de control</h2>
                        <p><?php echo $dashboardContent; ?></p>
                        <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
