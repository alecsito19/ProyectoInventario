<?php

include("db.php");

if (isset($_GET['id'])){
    $id=$_GET['id'];
    $query="DELETE FROM task WHERE id= $id";
    $result=mysqli_query($conn,$query);
    if(!$result){
        die("Error de conexión");
    }

    $_SESSION['message'] = 'Registro eliminado';
    $_SESSION['message_type']='danger';


}

header("Location: usuarios.php");
?>
